/*
 * In-Game Account Switcher is a mod for Minecraft that allows you to change your logged in account in-game, without restarting Minecraft.
 * Copyright (C) 2015-2022 The_Fireplace
 * Copyright (C) 2021-2026 VidTu
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package ru.vidtu.ias.screen;

//? if >=26.1 {
import net.minecraft.client.gui.GuiGraphicsExtractor;
//?} else
/*import net.minecraft.client.gui.GuiGraphics;*/
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;
import ru.vidtu.ias.account.Account;
import ru.vidtu.ias.config.IASConfig;
import ru.vidtu.ias.crypt.DummyCrypt;
import ru.vidtu.ias.crypt.HardwareCrypt;

import java.time.Duration;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Microsoft crypt type popup screen.
 *
 * @author VidTu
 */
final class MicrosoftCryptPopupScreen extends Screen {
    /**
     * Parent screen.
     */
    private final Screen parent;

    /**
     * Account handler.
     */
    private final Consumer<Account> handler;

    /**
     * No encryption.
     */
    private PopupButton plain;

    /**
     * Creates a new add screen.
     *
     * @param parent  Parent screen
     * @param handler Account handler
     */
    MicrosoftCryptPopupScreen(Screen parent, Consumer<Account> handler) {
        super(Component.translatable("ias.microsoft"));
        this.parent = parent;
        this.handler = handler;
    }

    @Override
    protected void init() {
        // Bruh.
        assert this.minecraft != null;

        // Init parent.
        if (this.parent != null) {
            //? if >=1.21.11 {
            this.parent.init(this.width, this.height);
            //?} else
            /*this.parent.init(this.minecraft, this.width, this.height);*/
        }

        // Add password button.
        PopupButton button = new PopupButton(this.width / 2 - 75, this.height / 2 - 24 - 12, 150, 20, Component.translatable("ias.microsoft.password"), btn -> {
            //$set_screen 'this.minecraft' 'new MicrosoftPopupScreen(this.parent, this.handler, null)'
            this.minecraft.gui.setScreen(new MicrosoftPopupScreen(this.parent, this.handler, null));
        }, Supplier::get);
        button.setTooltip(Tooltip.create(Component.translatable("ias.microsoft.password.tip")));
        button.setTooltipDelay(Duration.ofMillis(250L));
        button.color(0.5F, 1.0F, 0.5F, true);
        this.addRenderableWidget(button);

        // Add hardware button.
        button = new PopupButton(this.width / 2 - 75, this.height / 2 - 12, 150, 20, Component.translatable("ias.microsoft.hardware"), btn -> {
            //$set_screen 'this.minecraft' 'new MicrosoftPopupScreen(this.parent, this.handler, HardwareCrypt.INSTANCE_V2)'
            this.minecraft.gui.setScreen(new MicrosoftPopupScreen(this.parent, this.handler, HardwareCrypt.INSTANCE_V2));
        }, Supplier::get);
        button.setTooltip(Tooltip.create(Component.translatable("ias.microsoft.hardware.tip")));
        button.setTooltipDelay(Duration.ofMillis(250L));
        button.color(1.0F, 1.0F, 0.5F, true);
        this.addRenderableWidget(button);

        // Add plain button.
        this.plain = new PopupButton(this.width / 2 - 75, this.height / 2 + 12, 150, 20, Component.translatable("ias.microsoft.plain"), btn -> {
            //$set_screen 'this.minecraft' 'new MicrosoftPopupScreen(this.parent, this.handler, DummyCrypt.INSTANCE)'
            this.minecraft.gui.setScreen(new MicrosoftPopupScreen(this.parent, this.handler, DummyCrypt.INSTANCE));
        }, Supplier::get);
        if (IASConfig.allowNoCrypt) {
            this.plain.setTooltip(Tooltip.create(Component.translatable("ias.microsoft.plain.tip.off", Component.translatable("key.keyboard.left.alt"), GLFW.glfwGetKeyName(GLFW.GLFW_KEY_Y, GLFW.GLFW_KEY_UNKNOWN))));
        } else {
            this.plain.setTooltip(Tooltip.create(Component.translatable("ias.microsoft.plain.tip.no")));
        }
        this.plain.setTooltipDelay(Duration.ofMillis(250L));
        this.plain.color(1.0F, 0.5F, 0.5F, true);
        this.plain.active = false;
        this.addRenderableWidget(this.plain);

        // Add cancel button.
        this.addRenderableWidget(new PopupButton(this.width / 2 - 75, this.height / 2 + 79 - 22, 150, 20,
                CommonComponents.GUI_CANCEL, btn -> this.onClose(), Supplier::get));
    }

    @Override
    //? if >=26.1 {
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
    //?} else
    /*public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {*/
        // Bruh.
        assert this.minecraft != null;
        Matrix3x2fStack pose = graphics.pose();

        // Render background and widgets.
        //? if >=26.1 {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        //?} else
        /*super.render(graphics, mouseX, mouseY, delta);*/

        // Render the title.
        pose.pushMatrix();
        pose.scale(2.0F, 2.0F);
        //? if >=26.1 {
        graphics.centeredText(this.font, this.title, this.width / 4, this.height / 4 - 79 / 2, 0xFF_FF_FF_FF);
        //?} else
        /*graphics.drawCenteredString(this.font, this.title, this.width / 4, this.height / 4 - 79 / 2, 0xFF_FF_FF_FF);*/
        pose.popMatrix();
    }

    @Override
    //? if >=26.1 {
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
    //?} else
    /*public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float delta) {*/
        // Bruh.
        assert this.minecraft != null;

        // Render transparent background if parent exists.
        if (this.parent != null) {
            // Render gradient.
            //? if >=26.1 {
            this.parent.extractRenderStateWithTooltipAndSubtitles(graphics, 0, 0, delta);
            //?} elif >= 1.21.10 {
            /*this.parent.renderWithTooltipAndSubtitles(graphics, 0, 0, delta);
            *///?} else
            /*this.parent.renderWithTooltip(graphics, 0, 0, delta);*/
            graphics.nextStratum();
            graphics.fill(0, 0, this.width, this.height, 0x80_00_00_00);
        } else {
            //? if >=26.1 {
            super.extractBackground(graphics, mouseX, mouseY, delta);
            //?} else
            /*super.renderBackground(graphics, mouseX, mouseY, delta);*/
        }

        // Render "form".
        int centerX = this.width / 2;
        int centerY = this.height / 2;
        GlassUI.panel(graphics, centerX - 80, centerY - 80, 160, 160);
    }

    @Override
    public void onClose() {
        // Bruh.
        assert this.minecraft != null;

        // Close to parent.
        //$set_screen 'this.minecraft' 'this.parent'
        this.minecraft.gui.setScreen(this.parent);
    }

    @Override
    //? if >= 1.21.10 {
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        int key = event.key();
        boolean alt = event.hasAltDown();
    //?} else {
    /*public boolean keyPressed(int key, int scan, int mods) {
        boolean alt = Screen.hasAltDown();
    *///?}
        // Enable plain.
        if (key == GLFW.GLFW_KEY_Y && IASConfig.allowNoCrypt && this.plain != null && !this.plain.isActive() && alt) {
            // Activate button.
            this.plain.active = true;

            // Recolor button and update tooltip.
            this.plain.setTooltip(Tooltip.create(Component.translatable("ias.microsoft.plain.tip.on")));
            this.plain.setTooltipDelay(Duration.ofMillis(250L));
            this.plain.color(1.0F, 0.25F, 0.25F, false);
        }

        // Pass-through.
        //? if >=1.21.10 {
        return super.keyPressed(event);
        //?} else
        /*return super.keyPressed(key, scan, mods);*/
    }

    @Override
    public String toString() {
        return "MicrosoftCryptPopupScreen{}";
    }
}
